<?php
/**
 * WordPress için taban ayar dosyası.
 *
 * Bu dosya şu ayarları içerir: MySQL ayarları, tablo öneki,
 * gizli anahtaralr ve ABSPATH. Daha fazla bilgi için 
 * {@link https://codex.wordpress.org/Editing_wp-config.php wp-config.php düzenleme}
 * yardım sayfasına göz atabilirsiniz. MySQL ayarlarınızı servis sağlayıcınızdan edinebilirsiniz.
 *
 * Bu dosya kurulum sırasında wp-config.php dosyasının oluşturulabilmesi için
 * kullanılır. İsterseniz bu dosyayı kopyalayıp, ismini "wp-config.php" olarak değiştirip,
 * değerleri girerek de kullanabilirsiniz.
 *
 * @package WordPress
 */

// ** MySQL ayarları - Bu bilgileri sunucunuzdan alabilirsiniz ** //
/** WordPress için kullanılacak veritabanının adı */
define('DB_NAME', 'movie-deneme');

/** MySQL veritabanı kullanıcısı */
define('DB_USER', 'root');

/** MySQL veritabanı parolası */
define('DB_PASSWORD', '');

/** MySQL sunucusu */
define('DB_HOST', 'localhost');

/** Yaratılacak tablolar için veritabanı karakter seti. */
define('DB_CHARSET', 'utf8mb4');

/** Veritabanı karşılaştırma tipi. Herhangi bir şüpheniz varsa bu değeri değiştirmeyin. */
define('DB_COLLATE', '');

/**#@+
 * Eşsiz doğrulama anahtarları.
 *
 * Her anahtar farklı bir karakter kümesi olmalı!
 * {@link http://api.wordpress.org/secret-key/1.1/salt WordPress.org secret-key service} servisini kullanarak yaratabilirsiniz.
 * Çerezleri geçersiz kılmak için istediğiniz zaman bu değerleri değiştirebilirsiniz. Bu tüm kullanıcıların tekrar giriş yapmasını gerektirecektir.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'd{tv`.RUPZ,0v2?=<:b{/x(iytNtp0tN54]H(oW>;K~x9ef3tCBEUfcNz:zPOD,L');
define('SECURE_AUTH_KEY',  'noM$mtQKdwP;^SY#6R@aR2EcR[%;j%&b}bgXD102@oc2<@c`Ek3SkelF9EK5oO:O');
define('LOGGED_IN_KEY',    'JB]C]${JQ*r]+2t)q/`D;dI6znoRJ:1Y> #^$M$KQsa</1.zKa52{36XAX~qam5M');
define('NONCE_KEY',        'n_Pusr%Oaq7Mde@&BB2Z?X@9+Bv`91r{UCE<k(`bHDFuI-iP?f=O`zdp!Eswoof#');
define('AUTH_SALT',        'nxs/^7;:K3a)*MmXt3P;)BXHq^ka=z%/IcE]px$Bx./>cT{q>M>&5LF=;uLXM*sd');
define('SECURE_AUTH_SALT', '9/7IGV=K!GM#DnBozGJjxx&*StRX{cyUv>g>c<>JsEPd57Tc(?.g4znj%3O:;dM#');
define('LOGGED_IN_SALT',   'U#a:z~7FJNfxgg>ODEw`ZtJcx8.p}%+~z~jjmY@k,E<?t]K]k{p2X,QCQDxxfZ8U');
define('NONCE_SALT',       '0D?Smmpsv6_ zc)^J:Ey+PO2JT1!l8<*,oL=kPnCA=/n .m%<a?P#HWBXU~ {$<y');
/**#@-*/

/**
 * WordPress veritabanı tablo ön eki.
 *
 * Tüm kurulumlara ayrı bir önek vererek bir veritabanına birden fazla kurulum yapabilirsiniz.
 * Sadece rakamlar, harfler ve alt çizgi lütfen.
 */
$table_prefix  = 'wp_';

/**
 * Geliştiriciler için: WordPress hata ayıklama modu.
 *
 * Bu değeri "true" yaparak geliştirme sırasında hataların ekrana basılmasını sağlayabilirsiniz.
 * Tema ve eklenti geliştiricilerinin geliştirme aşamasında WP_DEBUG
 * kullanmalarını önemle tavsiye ederiz.
 */
define('WP_DEBUG', true);

/* Hepsi bu kadar. Mutlu bloglamalar! */

/** WordPress dizini için mutlak yol. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** WordPress değişkenlerini ve yollarını kurar. */
require_once(ABSPATH . 'wp-settings.php');
